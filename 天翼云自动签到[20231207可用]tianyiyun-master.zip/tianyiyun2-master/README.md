# 天翼云自动签到
天翼云盘每日签到一次，抽奖2次  
使用方法  
1.测试环境为python3.7.6,自行安装python3  
2.requirements.txt 是所需第三方模块，执行 `pip install -r requirements.txt` 安装模块  
3.可在脚本内直接填写账号密码  
4.Python 和需要模块都装好了直接在目录 cmd 运行所要运行的脚本。  

# 在checkin.py的13、14两行的引号内贴上账号（仅支持手机号）和密码
username = " "
password = " "

此后，将会在每天10:00和22:00各签到一次  
若有需求，可以在[.github/workflows/check-in.yml]中自行修改。

